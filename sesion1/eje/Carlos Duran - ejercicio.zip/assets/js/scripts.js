function calcular() {
    const monto = parseFloat(document.getElementById('monto').value);
    const interes = parseFloat(document.getElementById('interes').value);
    const plazo = parseInt(document.getElementById('plazo').value);
    const calculo = (monto, interes, plazo) => document.getElementById('resultado').innerHTML = `<h3>¡NO TE PREOCUPES! PUEDES PAGARLO EN ${plazo} CUOTAS DE $ ${((monto * (1 + (interes / 100))) / plazo)}.</h3>`;


    if (monto > 0 && interes >0 && plazo > 0){
        calculo(monto, interes, plazo);
    } else {
        document.getElementById('resultado').innerHTML = `<h3>¡DEBE INGRESAR VALORES PARA GENERAR EL CALCULO!.</h3>`;
    }   
}
  